
"use strict";

let GetInit = require('./GetInit.js')

module.exports = {
  GetInit: GetInit,
};
