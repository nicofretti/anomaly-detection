/*********************************************************************
* Software License Agreement (BSD License)
*
*  Copyright (c) 2017, Robotnik Automation, SLL.
*  Copyright (c) 2009, Willow Garage, Inc.
*  All rights reserved.
*
*  Redistribution and use in source and binary forms, with or without
*  modification, are permitted provided that the following conditions
*  are met:
*
*   * Redistributions of source code must retain the above copyright
*     notice, this list of conditions and the following disclaimer.
*   * Redistributions in binary form must reproduce the above
*     copyright notice, this list of conditions and the following
*     disclaimer in the documentation and/or other materials provided
*     with the distribution.
*   * Neither the name of Willow Garage, Inc. nor the names of its
*     contributors may be used to endorse or promote products derived
*     from this software without specific prior written permission.
*
*  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
*  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
*  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
*  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
*  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
*  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
*  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
*  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
*  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
*  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
*  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
*  POSSIBILITY OF SUCH DAMAGE.
********************************************************************/

#ifndef SERVICE_SHIFTER_SERVICE_SHIFTER_H
#define SERVICE_SHIFTER_SERVICE_SHIFTER_H

#include <ros/ros.h>
#include <ros/console.h>
#include <ros/assert.h>
#include <vector>
#include <string>
#include <string.h>

#include <ros/macros.h>
#include <ros/message_traits.h>

#ifdef ROS_BUILD_SHARED_LIBS    // ros is being built around shared libraries
#ifdef service_shifter_EXPORTS  // we are building a shared lib/dll
#define SERVICE_SHIFTER_DECL ROS_HELPER_EXPORT
#else  // we are using shared lib/dll
#define SERVICE_SHIFTER_DECL ROS_HELPER_IMPORT
#endif
#else  // ros is being built around static libraries
#define SERVICE_SHIFTER_DECL
#endif

namespace service_shifter
{
class ServiceShifterException : public ros::Exception
{
public:
  ServiceShifterException(const std::string& msg) : ros::Exception(msg)
  {
  }
};

class SERVICE_SHIFTER_DECL ServiceShifter
{
public:
  typedef boost::shared_ptr<ServiceShifter> Ptr;
  typedef boost::shared_ptr<ServiceShifter const> ConstPtr;

  int id_;  // used to track construction/destruction of objects

  // Constructor and destructor
  ServiceShifter() : id_(0), typed(false), initialized(false), msgBuf(NULL), msgBufUsed(0), msgBufAlloc(0)
  {
    //
    //     static int id = 0;
    //     id_=++id;
    //     ROS_INFO("Constructor%d", id_);
  }
  virtual ~ServiceShifter()
  {
    if (msgBuf)
      delete[] msgBuf;

    msgBuf = NULL;
    msgBufUsed = 0;
    msgBufAlloc = 0;

    //   ROS_INFO("Destructor%d", id_);
  }

  // Helpers for inspecting shapeshifter
  std::string const& getDataType() const
  {
    return datatype;
  }
  std::string const& getMD5Sum() const
  {
    return md5;
  }
  std::string const& getMessageDefinition() const
  {
    return msg_def;
  }

  void morph(const std::string& _md5sum, const std::string& _datatype, const std::string& _msg_def,
             const std::string& _latching)
  {
    // ROS_WARN("MORPH");
    md5 = _md5sum;
    datatype = _datatype;
    msg_def = _msg_def;
    latching = _latching;
    typed = md5 != "*";
  }

  ServiceShifter& operator=(const ServiceShifter& another)
  {
    // ROS_INFO("equal operator: d%d", id_, another.id_);
    if (initialized)
    {
      if (msgBuf != 0)
        delete[] msgBuf;
    }
    msgBufAlloc = another.msgBufAlloc;
    msgBufUsed = another.msgBufUsed;
    msgBuf = new uint8_t[msgBufAlloc];

    memcpy(msgBuf, another.msgBuf, msgBufUsed);

    initialized = true;
    return *this;
  }

  template <typename M>
  ServiceShifter(const M& m) : ServiceShifter()
  {
    // TODO: right now this method is duplicated, below is the non const version.
    // should be refactored to a new method
    // ROS_INFO("ConstructorFrom%s To ServiceShifter(cast Constructor): %d",
    // ::ros::message_traits::DataType<M>::value(), id_);

    // this method must read the msg info of M, assign it to the ServiceShifter and read the data
    // it does it by serializeing the right hand object (of whatever type) and deserializing to an ServiceShifter object
    // this works. however, not sure if will have better performance by doing the conversion as in the = operator

    // converts from M to ServiceShifter
    int object_size = ros::serialization::Serializer<M>::serializedLength(m);
    uint8_t data[object_size];

    ros::serialization::OStream ostream(data, object_size);
    ros::serialization::IStream istream(data, object_size);
    ros::serialization::serialize(ostream, m);
    ros::serialization::deserialize(istream, *this);
  }

  template <typename M>
  ServiceShifter(M& m) : ServiceShifter()
  {
    // ROS_INFO("ConstructorFrom%s To ServiceShifter(cast Constructor): %d",
    // ::ros::message_traits::DataType<M>::value(), id_);

    // this method must read the msg info of M, assign it to the ServiceShifter and read the data
    // it does it by serializeing the right hand object (of whatever type) and deserializing to an ServiceShifter object
    // this works. however, not sure if will have better performance by doing the conversion as in the = operator

    // converts from M to ServiceShifter
    int object_size = ros::serialization::Serializer<M>::serializedLength(m);
    uint8_t data[object_size];

    ros::serialization::OStream ostream(data, object_size);
    ros::serialization::IStream istream(data, object_size);
    ros::serialization::serialize(ostream, m);
    ros::serialization::deserialize(istream, *this);
  }

  template <typename M>
  operator M() const
  {
    // This is the const cast operator. Used when casting the ::Request part. As const, cannot modify the current
    // object. That's why the instantiate method
    // has a false parameter, to not do type checking in case it has been initialized (has read data) but it does not
    // have type
    // It returns an empty object in case it has not been initialized. And it is not needed to modify the object

    // converts from ServiceShifter To const M
    // ROS_INFO("Const Cast from ServiceShifter To const %s: %d", ::ros::message_traits::DataType<M>::value(), id_);
    if (initialized)
      return *this->instantiate<M>(false);
    else
    {
      return M();
    }
  }

  template <typename M>
  operator M()
  {
    // This is the cast operator. Used when casting the ::Response part. This can modify the current object. As Response
    // must be typed to be, this one modifies the type.
    // and
    // converts from ServiceShifter To M
    // ROS_INFO("Cast from ServiceShifter To %s: %d", ::ros::message_traits::DataType<M>::value(), id_);

    if (!typed)
      morph(::ros::message_traits::MD5Sum<M>::value(), ::ros::message_traits::DataType<M>::value(),
            ::ros::message_traits::Definition<M>::value(), "false");

    if (initialized)
      return *this->instantiate<M>();
    else
    {
      M m;

      // we really need to allocate space??
      msgBufAlloc = ros::serialization::Serializer<M>::serializedLength(m);
      msgBuf = new uint8_t[msgBufAlloc];

      ros::serialization::OStream s(msgBuf, msgBufAlloc);
      ros::serialization::serialize(s, m);

      initialized = true;
      return m;
    }
  }

  friend std::ostream& operator<<(std::ostream& stream, const ServiceShifter& value);
  // Helper for advertising. Is inherited from the topic_tools::ShapeShifter, but not used in the service
  ros::Publisher advertise(ros::NodeHandle& nh, const std::string& topic, uint32_t queue_size_, bool latch = false,
                           const ros::SubscriberStatusCallback& connect_cb = ros::SubscriberStatusCallback()) const
  {
    // ROS_WARN("ADVERTISE");
    ros::AdvertiseOptions opts(topic, queue_size_, getMD5Sum(), getDataType(), getMessageDefinition(), connect_cb);
    opts.latch = latch;

    return nh.advertise(opts);
  }

  //! Call to try instantiating as a particular type
  template <class M>
  boost::shared_ptr<M> instantiate(bool check_typed = true) const;

  //! Write serialized message contents out to a stream
  template <typename Stream>
  void write(Stream& stream) const;

  template <typename Stream>
  void read(Stream& stream);

  //! Return the size of the serialized message
  uint32_t size() const
  {
    return msgBufUsed;
  }

private:
  std::string md5, datatype, msg_def, latching;
  bool typed;
  bool initialized;

  uint8_t* msgBuf;
  uint32_t msgBufUsed;
  uint32_t msgBufAlloc;
};
}

// Message traits allow shape shifter to work with the new serialization API
namespace ros
{
namespace message_traits
{
template <>
struct IsMessage<service_shifter::ServiceShifter> : TrueType
{
};
template <>
struct IsMessage<const service_shifter::ServiceShifter> : TrueType
{
};

template <>
struct MD5Sum<service_shifter::ServiceShifter>
{
  static const char* value(const service_shifter::ServiceShifter& m)
  {
    // ROS_WARN("message_traits::MD5sum with arg");
    return m.getMD5Sum().c_str();
  }

  // Used statically, a shapeshifter appears to be of any type
  static const char* value()
  {
    // ROS_WARN("message_traits::MD5sum NO arg");
    return "*";
  }
};

template <>
struct DataType<service_shifter::ServiceShifter>
{
  static const char* value(const service_shifter::ServiceShifter& m)
  {
    // ROS_WARN("message_traits::DataType with arg");
    return m.getDataType().c_str();
  }

  // Used statically, a shapeshifter appears to be of any type
  static const char* value()
  {
    // ROS_WARN("message_traits::DataType NO arg");
    return "*";
  }
};

template <>
struct Definition<service_shifter::ServiceShifter>
{
  static const char* value(const service_shifter::ServiceShifter& m)
  {
    // ROS_WARN("message_traits::Definition with arg");
    return m.getMessageDefinition().c_str();
  }
};

}  // namespace message_traits

namespace serialization
{
template <>
struct Serializer<service_shifter::ServiceShifter>
{
  template <typename Stream>
  inline static void write(Stream& stream, const service_shifter::ServiceShifter& m)
  {
    // ROS_WARN("serializer::write::%d", m.id_);
    m.write(stream);
  }

  template <typename Stream>
  inline static void read(Stream& stream, service_shifter::ServiceShifter& m)
  {
    // ROS_WARN("serializer::read::%d", m.id_);
    m.read(stream);
  }

  inline static uint32_t serializedLength(const service_shifter::ServiceShifter& m)
  {
    // ROS_WARN("serializer::size::%d", m.id_);
    return m.size();
  }

};  // class

template <>
struct PreDeserialize<service_shifter::ServiceShifter>
{
  static void notify(const PreDeserializeParams<service_shifter::ServiceShifter>& params)
  {
    //    ROS_WARN("predeserialize::notify");
    std::string md5 = (*params.connection_header)["md5sum"];
    std::string datatype = (*params.connection_header)["type"];
    std::string msg_def = (*params.connection_header)["message_definition"];
    std::string latching = (*params.connection_header)["latching"];

    params.message->morph(md5, datatype, msg_def, latching);
  }
};

}  // namespace serialization

}  // namespace ros

// Template implementations:

namespace service_shifter
{
//
//  only used in testing, seemingly
//
template <class M>
boost::shared_ptr<M> ServiceShifter::instantiate(bool check_typed) const
{
  // ROS_WARN("topic_tool: instantiate %d", id_);

  if (check_typed)
  {
    if (!typed)
      throw ServiceShifterException("Tried to instantiate message from an untyped shapeshifter.");

    if (ros::message_traits::datatype<M>() != getDataType())
      throw ServiceShifterException("Tried to instantiate message without matching datatype.");

    if (ros::message_traits::md5sum<M>() != getMD5Sum())
      throw ServiceShifterException("Tried to instantiate message without matching md5sum.");
  }
  boost::shared_ptr<M> p(boost::make_shared<M>());

  ros::serialization::IStream s(msgBuf, msgBufAlloc);
  ros::serialization::deserialize(s, *p);

  return p;
}

template <typename Stream>
void ServiceShifter::write(Stream& stream) const
{
  // ROS_WARN("write %d", id_);
  if (msgBufUsed > 0)
    memcpy(stream.advance(msgBufUsed), msgBuf, msgBufUsed);
}

template <typename Stream>
void ServiceShifter::read(Stream& stream)
{
  // ROS_WARN("read %d", id_);
  // stash this message in our buffer
  if (stream.getLength() > msgBufAlloc)
  {
    if (msgBuf != 0)
      delete[] msgBuf;
    msgBuf = new uint8_t[stream.getLength()];
    msgBufAlloc = stream.getLength();
  }
  msgBufUsed = stream.getLength();
  memcpy(msgBuf, stream.getData(), stream.getLength());
  initialized = true;
}

template <typename T>
std::ostream& operator<<(std::ostream& stream, const ServiceShifter& value)
{
  stream << "length: " << value.msgBufUsed << " (allocated: " << value.msgBufAlloc << ")" << std::endl;
  stream << "used: ";
  for (size_t i = 0; i < value.msgBufUsed; i++)
    stream << " " << unsigned(value.msgBuf[i]);
  stream << "allocated: ";
  for (size_t i = 0; i < value.msgBufAlloc; i++)
    stream << " " << unsigned(value.msgBuf[i]);
  stream << std::endl;
}

}  // namespace service_shifter

#endif
