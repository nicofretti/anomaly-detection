
"use strict";

let RobotnikMoveBaseFlexResultAction = require('./RobotnikMoveBaseFlexResultAction.js');
let RobotnikMoveBaseFlexFeedbackAction = require('./RobotnikMoveBaseFlexFeedbackAction.js');
let PoseStampedArray = require('./PoseStampedArray.js');
let RobotnikMoveBaseFlexGoalAction = require('./RobotnikMoveBaseFlexGoalAction.js');
let BarcodeDockAction = require('./BarcodeDockAction.js');
let BarcodeDockActionGoal = require('./BarcodeDockActionGoal.js');
let DockActionResult = require('./DockActionResult.js');
let RobotnikMoveBaseFlexFeedback = require('./RobotnikMoveBaseFlexFeedback.js');
let BarcodeDockGoal = require('./BarcodeDockGoal.js');
let DockFeedback = require('./DockFeedback.js');
let MoveGoal = require('./MoveGoal.js');
let MoveResult = require('./MoveResult.js');
let DockActionFeedback = require('./DockActionFeedback.js');
let MoveActionResult = require('./MoveActionResult.js');
let DockAction = require('./DockAction.js');
let MoveAction = require('./MoveAction.js');
let RobotnikMoveBaseFlexResult = require('./RobotnikMoveBaseFlexResult.js');
let DockActionGoal = require('./DockActionGoal.js');
let RobotnikMoveBaseFlexActionResult = require('./RobotnikMoveBaseFlexActionResult.js');
let DockGoal = require('./DockGoal.js');
let BarcodeDockFeedback = require('./BarcodeDockFeedback.js');
let MoveActionFeedback = require('./MoveActionFeedback.js');
let MoveFeedback = require('./MoveFeedback.js');
let RobotnikMoveBaseFlexActionFeedback = require('./RobotnikMoveBaseFlexActionFeedback.js');
let RobotnikMoveBaseFlexGoal = require('./RobotnikMoveBaseFlexGoal.js');
let RobotnikMoveBaseFlexActionGoal = require('./RobotnikMoveBaseFlexActionGoal.js');
let BarcodeDockActionFeedback = require('./BarcodeDockActionFeedback.js');
let BarcodeDockActionResult = require('./BarcodeDockActionResult.js');
let DockResult = require('./DockResult.js');
let BarcodeDockResult = require('./BarcodeDockResult.js');
let MoveActionGoal = require('./MoveActionGoal.js');
let RobotnikMoveBaseFlexAction = require('./RobotnikMoveBaseFlexAction.js');

module.exports = {
  RobotnikMoveBaseFlexResultAction: RobotnikMoveBaseFlexResultAction,
  RobotnikMoveBaseFlexFeedbackAction: RobotnikMoveBaseFlexFeedbackAction,
  PoseStampedArray: PoseStampedArray,
  RobotnikMoveBaseFlexGoalAction: RobotnikMoveBaseFlexGoalAction,
  BarcodeDockAction: BarcodeDockAction,
  BarcodeDockActionGoal: BarcodeDockActionGoal,
  DockActionResult: DockActionResult,
  RobotnikMoveBaseFlexFeedback: RobotnikMoveBaseFlexFeedback,
  BarcodeDockGoal: BarcodeDockGoal,
  DockFeedback: DockFeedback,
  MoveGoal: MoveGoal,
  MoveResult: MoveResult,
  DockActionFeedback: DockActionFeedback,
  MoveActionResult: MoveActionResult,
  DockAction: DockAction,
  MoveAction: MoveAction,
  RobotnikMoveBaseFlexResult: RobotnikMoveBaseFlexResult,
  DockActionGoal: DockActionGoal,
  RobotnikMoveBaseFlexActionResult: RobotnikMoveBaseFlexActionResult,
  DockGoal: DockGoal,
  BarcodeDockFeedback: BarcodeDockFeedback,
  MoveActionFeedback: MoveActionFeedback,
  MoveFeedback: MoveFeedback,
  RobotnikMoveBaseFlexActionFeedback: RobotnikMoveBaseFlexActionFeedback,
  RobotnikMoveBaseFlexGoal: RobotnikMoveBaseFlexGoal,
  RobotnikMoveBaseFlexActionGoal: RobotnikMoveBaseFlexActionGoal,
  BarcodeDockActionFeedback: BarcodeDockActionFeedback,
  BarcodeDockActionResult: BarcodeDockActionResult,
  DockResult: DockResult,
  BarcodeDockResult: BarcodeDockResult,
  MoveActionGoal: MoveActionGoal,
  RobotnikMoveBaseFlexAction: RobotnikMoveBaseFlexAction,
};
