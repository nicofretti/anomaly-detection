
"use strict";

let MovementStatus = require('./MovementStatus.js');

module.exports = {
  MovementStatus: MovementStatus,
};
