#ifndef _ROBOT_LOCAL_CONTROL_ODOMETER_
#define _ROBOT_LOCAL_CONTROL_ODOMETER_

#include <ros/ros.h>

#include <geometry_msgs/Twist.h>
#include <geometry_msgs/TwistStamped.h>
#include <geometry_msgs/Pose2D.h>

class Odometer
{
public:
  Odometer()
  {
    travelled_ = geometry_msgs::Pose2D();
    stamp_last_measurement_ = ros::Time(0);
  }

  void addMeasurement(const geometry_msgs::Twist& twist)
  {
    geometry_msgs::TwistStamped ts;
    ts.twist = twist;
    ts.header.stamp = ros::Time::now();
    addMeasurement(ts);
  }

  void addMeasurement(const geometry_msgs::TwistStamped& twist)
  {
    if (stamp_last_measurement_ == ros::Time(0))
    {
      stamp_last_measurement_ = twist.header.stamp;
      return;
    }

    travelled_.x = std::abs(twist.twist.linear.x * (ros::Time::now() - stamp_last_measurement_).toSec());
    travelled_.y = std::abs(twist.twist.linear.y * (ros::Time::now() - stamp_last_measurement_).toSec());
    travelled_.theta = std::abs(twist.twist.angular.x * (ros::Time::now() - stamp_last_measurement_).toSec());

    stamp_last_measurement_ = ros::Time::now();
  }

  geometry_msgs::Pose2D getDistanceTravelled()
  {
    return travelled_;
  }

  double getMetersTravelled()
  {
    return travelled_.x + travelled_.y;
  }

  double getTurnsTravelled()
  {
    return travelled_.theta / 2.0 * M_PI;
  }

  void reset()
  {
    travelled_ = geometry_msgs::Pose2D();
  }

  // bool addLap(std::string lap)
  // {
  // }

  // bool resetLap(std::string lap)
  // {
  // }
  //
  // geometry_msgs::Pose2D getDistanceTravelledInLap(std::string lap)
  // {
  // }

  // double getMetersTravelledInLap(std::string lap)
  // {
  // }
  //
  // double getTurnsTravelled(std::string lap)
  // {
  // }
private:
  geometry_msgs::Pose2D travelled_;
  ros::Time stamp_last_measurement_;
  // std::vector<std::pair<std::string, geometry_msgs::Pose2D> > laps_;
};
#endif  // _ROBOT_LOCAL_CONTROL_ODOMETER_
