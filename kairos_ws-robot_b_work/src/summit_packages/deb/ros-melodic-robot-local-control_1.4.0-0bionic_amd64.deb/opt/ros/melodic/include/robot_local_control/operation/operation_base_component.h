#ifndef _ROBOT_LOCAL_CONTROL_OPERATION_COMPONENT_BASE_
#define _ROBOT_LOCAL_CONTROL_OPERATION_COMPONENT_BASE_

#include <ros/ros.h>

#include <tf/tf.h>
#include <tf/transform_listener.h>

#include <robot_local_control/robot_local_control_component.h>

namespace robot_local_control
{
class OperationComponentBase : public robot_local_control::RobotLocalControlComponent
{
public:
  OperationComponentBase(ros::NodeHandle h = ros::NodeHandle("~"), std::string name = "OperationComponent")
  {
  }

  virtual ~OperationComponentBase()
  {
  }

  static inline std::string getBaseType()
  {
    return std::string("OperationComponent");
  }
  virtual std::string getType()
  {
    return getBaseType();
  }

  //  virtual std::string getCurrentState();
  // TODO: not sure if this name is the best... Because we have other components that also have
  // an "internal" machine, different from the "normal" state machine (init, standby, ready...)
  virtual std::string getCurrentOperation() = 0;
};

}  // namespace
#endif  //_ROBOT_LOCAL_CONTROL_OPERATION_COMPONENT_BASE_
