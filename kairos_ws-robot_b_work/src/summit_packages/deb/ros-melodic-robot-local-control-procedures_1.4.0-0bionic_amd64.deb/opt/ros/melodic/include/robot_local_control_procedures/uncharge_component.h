#ifndef __PROCEDURE_COMPONENT_UNCHARGE_H
#define __PROCEDURE_COMPONENT_UNCHARGE_H

#include <procedures/procedure_component.h>

#include <procedures_msgs/ProcedureQuery.h>
#include <procedures_msgs/ProcedureHeader.h>
#include <procedures_msgs/ProcedureState.h>
#include <procedures_msgs/ProcedureResult.h>

#include <std_srvs/SetBool.h>

#include <robot_local_control_msgs/Uncharge.h>
#include <robot_local_control_msgs/UnchargePetition.h>
#include <robot_local_control_msgs/Status.h>

#include <boost/scoped_ptr.hpp>

#include <actionlib/client/simple_action_client.h>

#include <robotnik_navigation_msgs/MoveAction.h>

#include <robotnik_msgs/SetLaserMode.h>
#include <robotnik_msgs/LaserMode.h>

struct UnchargeProcedure
{
  robot_local_control_msgs::Uncharge procedure;
  procedures_msgs::ProcedureHeader header;
  procedures_msgs::ProcedureState state;

  typedef robot_local_control_msgs::Uncharge Type;
  typedef robot_local_control_msgs::UnchargePetition Petition;
};

namespace procedures
{
class ProcedureComponentUncharge : public ProcedureComponent<UnchargeProcedure>
{
public:
  ProcedureComponentUncharge();
  ProcedureComponentUncharge(ros::NodeHandle h, std::string name = "UnchargeComponent");

  virtual bool addProcedure(const UnchargeProcedure::Petition::Request& request,
                            UnchargeProcedure::Petition::Response& response);

  virtual bool cancelProcedure(procedures_msgs::ProcedureQuery::Request& request,
                               procedures_msgs::ProcedureQuery::Response& response);

  virtual bool cancelAllProcedures(procedures_msgs::ProcedureQuery::Request& request,
                                   procedures_msgs::ProcedureQuery::Response& response);

  virtual bool cancelAllProcedures();

  void setDockComponent(procedures::GenericProcedureComponent::Ptr component);
  void setMoveComponent(procedures::GenericProcedureComponent::Ptr component);

  enum Steps
  {
    Init = 0,
    DisableLasersFromStandby = 1,
    DisableChargeRelay = 2,
    Move = 3,
    Rotate = 4,
    ChangeLasersSecurity = 5
  };

protected:
  virtual void rosReadParams();
  virtual int rosSetup();
  virtual int setup();
  virtual std::string stepToString(int step);

  virtual void initState();
  virtual void standbyState();
  virtual void readyState();
  void stopActionGoals();

  bool isChargerRelayActive();
  std::string getBatteryOperationMode();
  void robotStatusCallback(const robot_local_control_msgs::Status& status);
  bool areLasersInStandby();
  int disableChargeRelay(std::string& msg);
  int changeLasersSecurity(std::string laser_mode, std::string& msg);
  bool isLasersInDesiredMode(std::string laser_mode);
  std::string getLaserMode();
  int setLasersToStandby(std::string& msg);

  template <class T>
  int checkCurrentAction(T& current_action_client)
  {
    actionlib::SimpleClientGoalState action_state = current_action_client->getState();
    if (action_state.isDone() == true)
    {
      if (action_state == actionlib::SimpleClientGoalState::SUCCEEDED)
      {
        return 0;
      }
      else
      {
        return -1;
      }
    }
    return 1;
  }

  std::vector<GenericProcedureComponent::Ptr> components_;

  std::string move_namespace_;
  bool sent_, has_safety_laser_;
  std::string battery_docking_operation_mode_, laser_mode_at_finish_;

  ros::Subscriber robot_status_sub_;
  robot_local_control_msgs::Status robot_status_;

  boost::scoped_ptr<actionlib::SimpleActionClient<robotnik_navigation_msgs::MoveAction>> move_action_;

  double step_back_distance_;
  double rotation_;

  ros::ServiceClient enable_charge_client_;
  ros::ServiceClient laser_mode_client_;
  ros::ServiceClient set_to_standby_client_;

  geometry_msgs::Twist move_max_velocity_;
  static const double min_linear_velocity_, min_angular_velocity_;
  static const double min_step_back_distance_;
};
}  // namespace procedures
#endif  // __PROCEDURE_COMPONENT_UNCHARGE_H
