/*! \class MotorVelocity
 *	\author Robotnik Automation S.L.L
 *	\version 2.0
 *	\date 2012
 *  \brief Class for motor drive in velocity mode
 *  All rights reserved.
*/

#include <robotnik_base_hw_lib/MotorDrive.h>

#ifndef _ROBOTNIK_BASE_HW_MOTOR_VELOCITY_H_
#define _ROBOTNIK_BASE_HW_MOTOR_VELOCITY_H_

#define K_GEARBOX_V 1.0      // Gearbox reduction motor to output
#define SPINDLE_STEP_MM 1.0  //

class MotorVelocity : public MotorDrive
{
private:
  //! Use position instead of velocity for motor velocity calculation
  bool calculateVelUsingPose;
  bool firstPoseRead;
  ros::Time lastReadTime;
  double lastReadPose;
  //! Diameter of the motor wheel
  double dMotorWheelDiameter;
  //! constant to convert velocity from mps to drive units
  double dMps2Ref;
  //! constant to convert velocity from drive units to mps
  double dRef2Mps;
  //! constant to convert velocity from mps to drive units
  double dRps2Ref;
  //! constant to convert velocity from drive units to mps
  double dRef2Rps;
  //! Gearbox relation
  double gearbox;
  //! Motors Encoder
  //! If Motors with encoder speed must be multiplied by Motors_Encoders_Factor
  //! DO NOT USE IF motors without encoder
  bool bMotorsEncoder;
  double dMotorsEncoderFactor;
  //! Constant to convert radians to drive's reference
  double dPos2Ref;
  //! Constant to convert drive's reference to radians
  double dRef2Pos;

public:
  MotorVelocity(byte can_id, PCan* can_device, double hz, KinematicParams* kin_par, ControlParams* ctrl_par, IoParams* io_params);

  //! public destructor
  ~MotorVelocity(void);
  //! function to get the motor velocity in m/s
  double GetMotorVelocity();
  //! function to get the motor velocity in rad/s
  double GetMotorVelocityRps();
  //! function to set motor's position
  //! @param position as a int, target position
  //! @return OK
  //! @return ERROR
  Component::ReturnValue SetMotorVelocity(int velocity);
  //! function to set motor's velocity
  //! @param position as a double, target position in rads
  //! @return OK
  //! @return ERROR
  Component::ReturnValue SetMotorVelocity(double velocity);
  //! function to set motor's velocity
  //! @param position as a double, target position in rads
  //! @return OK
  //! @return ERROR
  Component::ReturnValue SetMotorVelocityRps(double velocity);
  //! Closes and frees the reserved resources
  //! @return OK
  //! @return ERROR if fails when closes the devices
  //! @return RUNNING if the component is running
  //! @return NOT_INITIALIZED if the component is not initialized
  Component::ReturnValue ShutDown();
  //! Sets the value of the diameter
  void SetWheelDiameter(double diameter);
  //! Gets the value of the diameter
  double GetWheelDiameter();
  //! Gets motor counts
  int GetMotorPosition();
  //! Gets motor position in rads
  double GetMotorPositionRads();

  bool IsHomingNeeded();
};

#endif  // _ROBOTNIK_BASE_HW_MOTOR_VELOCITY_H_
